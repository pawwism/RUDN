﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using static System.Runtime.InteropServices.JavaScript.JSType;
using System.Net.Sockets;
using System.Xml.Linq;

namespace APP1
{
    /// <summary>
    /// Логика взаимодействия для Cook.xaml
    /// </summary>
    public partial class Cook : Window
    {
        string connectionString;
        SqlConnection connection;
        int selectedOrderId;
        string statusC;
        DateTime? date;
        string fDate;
        DataTable datatable;
        SqlDataAdapter SqlUpdate;
        SqlCommandBuilder sqlSave;
        string sqlUpdate = "SELECT Id, StatusC FROM Zakaz";

        public Cook()
        {
            InitializeComponent();
            connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Учеба\\Готовый проект 2\\APP1\\FastFoodDB.mdf\";Integrated Security=True";
            connection = new SqlConnection(connectionString);
            connection.Open();
            dgZakazView.DataContext = ExecuteSql("SELECT Id, StatusC FROM Zakaz");         
            SqlUpdate = new SqlDataAdapter(sqlUpdate, connection);
            datatable = new DataTable();
            SqlUpdate.Fill(datatable);
            save();
        }
        DataTable ExecuteSql(string sql)
        {
            DataTable table = new();
            SqlCommand cmd = new(sql, connection);
            SqlDataReader read = cmd.ExecuteReader();
            using (read)
            {
                table.Load(read);
            }
            return table;
        }
        private void save()
        {
            sqlSave = new SqlCommandBuilder(SqlUpdate);
            SqlUpdate.Update(datatable);
            SqlUpdate = new SqlDataAdapter(sqlUpdate, connection);
            datatable = new DataTable();
            SqlUpdate.Fill(datatable);
            dgZakazView.DataContext = datatable;
        }

        private void btnCloseWaiter_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            connection.Close();
            Hide();
        }

        private void btnViewOrder_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null && btn.Tag != null)
            {
                selectedOrderId = (int)btn.Tag;

                TabItem viewOrderTab = MainTabControl.FindName("ZakazView") as TabItem;

                if (viewOrderTab != null)
                {
                    MainTabControl.SelectedItem = viewOrderTab;
                    dgOrder.DataContext = ExecuteSql($"SELECT Menu.Title AS ProductTitle, Menu.Price AS ProductPrice, ZakazMenu.Kolvo AS Quantity, Menu.Price * ZakazMenu.Kolvo AS TotalPrice FROM ZakazMenu JOIN Menu ON ZakazMenu.IdMenu = Menu.Id WHERE ZakazMenu.IdZakaz = '{selectedOrderId}'");
                }
                else
                {
                    viewOrderTab = new TabItem();
                    viewOrderTab.Header = "Просмотр заказов";
                    viewOrderTab.Name = "ZakazView";
                    MainTabControl.Items.Add(viewOrderTab);
                    MainTabControl.SelectedItem = viewOrderTab;
                    dgOrder.DataContext = ExecuteSql($"SELECT Menu.Title AS ProductTitle, Menu.Price AS ProductPrice, ZakazMenu.Kolvo AS Quantity, Menu.Price * ZakazMenu.Kolvo AS TotalPrice FROM ZakazMenu JOIN Menu ON ZakazMenu.IdMenu = Menu.Id WHERE ZakazMenu.IdZakaz = '{selectedOrderId}'");
                }
            }
        }

        private void UpdateStatus_Click(object sender, RoutedEventArgs e)
        {
            save();
        }

       
    }
    
}
