﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using Microsoft.VisualBasic;
using System.Net.NetworkInformation;
using System.Xml.Linq;

namespace APP1
{
    /// <summary>
    /// Логика взаимодействия для Admin.xaml
    /// </summary>
    public partial class Admin : Window
    {
        string connectionString;
        SqlConnection connection;
        string checkUser = "SELECT COUNT(*) FROM Users WHERE userLogin=@userLogin";
        string sqlUsers = "INSERT INTO Users(userName , userLogin, userPass, userStatus, idRole ) VALUES ( @userName, @userLogin, @userPass, @userStatus, (SELECT Id FROM Roles WHERE Roles.Role = @Role)) ";
        string sqlSave = "UPDATE Users SET userName = @userName, userPass=@userPass, idRole = (SELECT Id FROM Roles WHERE Roles.Role = @Role ), userStatus =@userStatus WHERE userLogin = @userLogin";
        string sqlUserRole = "Select Role from Roles ";
        string sqlAdmin = "Select userName from Users WHERE idRole='2' and userStatus=N'работает'";
        string sqlWaiter = "Select userName from Users WHERE idRole='3'";
        string sqlCook = "Select userName from Users WHERE idRole='4'";
        string sqlTable = "SELECT * FROM Users INNER JOIN Roles ON Roles.Id= Users.idRole ORDER BY Users.userStatus,Roles.Role";
        string sqlSmenaView = "SELECT Smena.dataSmena,Users.userName,Roles.Role FROM Users,Smena,SmenaUsers,Roles WHERE SmenaUsers.IdUsers=Users.Id and Roles.Id=Users.idRole and Smena.Id=SmenaUsers.IdSmena ORDER BY Smena.dataSmena, Roles.Role";
        string sqlUserSmena = "INSERT INTO SmenaUsers (IdUsers,IdSmena) VALUES ((SELECT Id FROM Users WHERE userName=@userName),(SELECT Id FROM Smena WHERE dataSmena=@dataSmena))";
        string checkDate = "SELECT COUNT(*) FROM Smena WHERE dataSmena=@dataSmena";
        string checkDateUserNew = "SELECT COUNT(*) FROM Users,Smena,SmenaUsers WHERE SmenaUsers.IdUsers=Users.Id and Users.userName=@userName and Smena.Id=SmenaUsers.IdSmena and dataSmena=@dataSmena";
        string sqlUpdate = @"SELECT Id, Date, Name, Number, Client, StatusW FROM Zakaz";
        string name;
        string login;
        string password;
        string role;
        string status;
        int selectedOrderId;
        string number;
        string client;
        string statusW;
        DateTime? date;
        string fDate;
        DataTable datatable;
        SqlDataAdapter SqlUpdate;


        public Admin()
        {
            InitializeComponent();
            connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Учеба\\Готовый проект 2\\APP1\\FastFoodDB.mdf\";Integrated Security=True";
            connection = new SqlConnection(connectionString);
            connection.Open();
            var roles = ExecuteSql(sqlUserRole).Rows.OfType<DataRow>().Select(dr => dr.Field<String>("Role"));
            cbUserRole.ItemsSource = roles;
            cbUserStatus.ItemsSource = new List<string>()
            { "работает","уволен" };
            dpSmena.SelectedDate = DateTime.Today;
            UpdateSmena();
            dgZakazView.DataContext = ExecuteSql("Select * from Zakaz");
            SqlUpdate = new SqlDataAdapter(sqlUpdate, connection);
            datatable = new DataTable();
            SqlUpdate.Fill(datatable);
            save();

        }
        private void UpdateUser()
        {
            name = txtUserName.Text;
            login = txtUserLogin.Text;
            password = txtUserPass.Text;
            role = cbUserRole.Text;
            status = cbUserStatus.Text;
        }
        private void UpdateSmena()
        {
            var admin = ExecuteSql(sqlAdmin).Rows.OfType<DataRow>().Select(dr => dr.Field<String>("userName"));
            var waiter = ExecuteSql(sqlWaiter).Rows.OfType<DataRow>().Select(dr => dr.Field<String>("userName"));
            var cook = ExecuteSql(sqlCook).Rows.OfType<DataRow>().Select(dr => dr.Field<String>("userName"));
            cbAdmin.ItemsSource = admin;
            cbWaiter.ItemsSource = waiter;
            cbCook.ItemsSource = cook;
        }

        DataTable ExecuteSql(string sql)
        {
            DataTable table = new();
            SqlCommand cmd = new(sql, connection);
            SqlDataReader read = cmd.ExecuteReader();
            using (read)
            {
                table.Load(read);
            }
            return table;
        }

        private void UpdateListSmena()
        {
            DateTime? date = dpSmena.SelectedDate;
            if (date.HasValue)
            {
                string fDate = date.Value.ToString("yyyy-MM-dd");
                DataTable dt = ExecuteSql($"SELECT Smena.dataSmena,Users.userName,Roles.Role FROM Users,Smena,SmenaUsers,Roles WHERE SmenaUsers.IdUsers=Users.Id and Smena.Id=SmenaUsers.IdSmena and Roles.Id = Users.idRole and Smena.DataSmena='{fDate}' ORDER BY Smena.dataSmena, Roles.Role");
                listSmena.ItemsSource = dt.DefaultView;
            }

        }
        private void btnUserView_Click(object sender, RoutedEventArgs e)
        {
            DataTable table = ExecuteSql(sqlTable);
            listUser.ItemsSource = table.DefaultView;
        }
        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            string userlogin = txtUserLogin.Text;
            string userSearch = "SELECT * FROM Users INNER JOIN Roles ON Users.idRole=Roles.id WHERE userLogin=@userLogin";
            using (SqlCommand search = new(userSearch, connection))
            {
                search.Parameters.AddWithValue("@userLogin", userlogin);
                using (SqlDataReader reader = search.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        lblMessage.Content = $"Сотрудник найден";
                        txtUserName.Text = reader["userName"].ToString();
                        txtUserPass.Text = reader["userPass"].ToString();
                        cbUserStatus.SelectedValue = reader["userStatus"].ToString().Trim();
                        cbUserRole.SelectedValue = reader["Role"].ToString();
                    }
                    else
                    {
                        lblMessage.Content = $"Не найден сотрудник";
                    }
                }
            }

        }
        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            UpdateUser();
            using (SqlCommand checkSave = new(checkUser, connection))
            {
                checkSave.Parameters.AddWithValue("@userLogin", login);
                int countLog = (int)checkSave.ExecuteScalar();
                if (countLog < 1)
                { lblMessage.Content = "Логин не найден"; return; }
            }
            using (SqlCommand save = new(sqlSave, connection))
            {
                save.Parameters.AddWithValue("@userName", name);
                save.Parameters.AddWithValue("@userLogin", login);
                save.Parameters.AddWithValue("@userPass", password);
                save.Parameters.AddWithValue("@Role", role);
                save.Parameters.AddWithValue("@userStatus", status);
                int countSave = save.ExecuteNonQuery();
                if (countSave > 0)
                {
                    lblMessage.Content = "Данные сохранены";
                }
                else { lblMessage.Content = "Не удалось сохранить изменения"; }
            }
            UpdateSmena();
        }
        private void btnReg_Click(object sender, RoutedEventArgs e)
        {
            UpdateUser();
            using (SqlCommand check = new(checkUser, connection))
            {
                check.Parameters.AddWithValue("@userLogin", login);
                int countCheck = (int)check.ExecuteScalar();
                if (countCheck > 0)
                { lblMessage.Content = "Логин уже зарегистрирован"; return; }
            }
            using (SqlCommand command = new(sqlUsers, connection))
            {
                command.Parameters.AddWithValue("@userName", name);
                command.Parameters.AddWithValue("@userLogin", login);
                command.Parameters.AddWithValue("@userPass", password);
                command.Parameters.AddWithValue("@Role", role);
                command.Parameters.AddWithValue("@userStatus", status);
                int countReg = command.ExecuteNonQuery();
                if (countReg > 0) { lblMessage.Content = "Сотрудник зарегистрирован"; }
                else { lblMessage.Content = "Регистрация неудачна"; }
            }
            UpdateSmena();
        }

        private void btnSmenaView_Click(object sender, RoutedEventArgs e)
        {
            DataTable table = ExecuteSql(sqlSmenaView);
            listSmena.ItemsSource = table.DefaultView;
        }
        private void set_Smena(string user)
        {
            DateTime? date = dpSmena.SelectedDate;
            string mes = "";
            using (SqlCommand checkNewDate = new(checkDate, connection))
            {
                checkNewDate.Parameters.AddWithValue("@dataSmena", date);
                int countDate = (int)checkNewDate.ExecuteScalar();
                if (countDate == 0)
                {
                    using (SqlCommand newDate = new("INSERT INTO Smena (dataSmena) VALUES (@dataSmena)", connection))
                    {
                        newDate.Parameters.AddWithValue("@dataSmena", date);
                        int countSave = newDate.ExecuteNonQuery();
                        if (countSave > 0)
                        {
                            mes = "Создана новая смена. ";
                        }
                        else { mes = ""; }
                    }
                }
                using (SqlCommand checkNewUser = new(checkDateUserNew, connection))
                {
                    checkNewUser.Parameters.AddWithValue("@dataSmena", date);
                    checkNewUser.Parameters.AddWithValue("@userName", user);
                    int countUser = (int)checkNewUser.ExecuteScalar();
                    if (countUser == 0)
                    {
                        using (SqlCommand command = new(sqlUserSmena, connection))
                        {
                            command.Parameters.AddWithValue("@userName", user);
                            command.Parameters.AddWithValue("@dataSmena", date);
                            int count = command.ExecuteNonQuery();
                            if (count > 0)
                            {
                                lblMessageSmena.Content = $"{mes}Сотрудник назначен";
                            }
                            else
                            {
                                lblMessageSmena.Content = $"{mes}Сотрудник не назначен";
                            }
                        }
                    }
                    else { lblMessageSmena.Content = $"Сотрудник уже назначен"; }
                }
            }

        }

        private void btnCookS_Click(object sender, RoutedEventArgs e)
        {
            string user = cbCook.Text;
            set_Smena(user);
            UpdateListSmena();
        }

        private void btnAdminS_Click(object sender, RoutedEventArgs e)
        {
            string user = cbAdmin.Text;
            set_Smena(user);
            UpdateListSmena();
        }
        private void btnWaiterS_Click(object sender, RoutedEventArgs e)
        {
            string user = cbWaiter.Text;
            set_Smena(user);
            UpdateListSmena();
        }
        private void btnSmenaDate_Click(object sender, RoutedEventArgs e)
        {
            UpdateListSmena();

        }

        private void btnSmenaUser_Click(object sender, RoutedEventArgs e)
        {
            login = txtUserLogin.Text;
            string sqlSmenaUser = $"SELECT Smena.dataSmena FROM Users,Smena,SmenaUsers WHERE SmenaUsers.IdUsers=Users.Id and userLogin='{login}' and Smena.Id=SmenaUsers.IdSmena ORDER BY Smena.dataSmena";
            DataTable table = ExecuteSql(sqlSmenaUser);
            listSmenaUser.ItemsSource = table.DefaultView;
        }


        private void btnCloseAdmin_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            connection.Close();
            Hide();
        }

        private void btnViewOrder_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null && btn.Tag != null)
            {
                selectedOrderId = (int)btn.Tag;

                TabItem viewOrderTab = MainTabControl.FindName("ZakazView") as TabItem;

                if (viewOrderTab != null)
                {
           
                    dgOrder.DataContext = ExecuteSql($"SELECT Menu.Title AS ProductTitle, Menu.Price AS ProductPrice, ZakazMenu.Kolvo AS Quantity, Menu.Price * ZakazMenu.Kolvo AS TotalPrice FROM ZakazMenu JOIN Menu ON ZakazMenu.IdMenu = Menu.Id WHERE ZakazMenu.IdZakaz = '{selectedOrderId}'");
                }
                else
                {
                    viewOrderTab = new TabItem();
                    viewOrderTab.Header = "Просмотр заказов";
                    viewOrderTab.Name = "ZakazView";

                  
                    dgOrder.DataContext = ExecuteSql($"SELECT Menu.Title AS ProductTitle, Menu.Price AS ProductPrice, ZakazMenu.Kolvo AS Quantity, Menu.Price * ZakazMenu.Kolvo AS TotalPrice FROM ZakazMenu JOIN Menu ON ZakazMenu.IdMenu = Menu.Id WHERE ZakazMenu.IdZakaz = '{selectedOrderId}'");
                }
            }
        }
        private void save()
        {
           
        }
    }
}

    

