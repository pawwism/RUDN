﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Data.SqlClient;
using System.Data;
using System.Net.Sockets;
using System.Xml.Linq;
using Microsoft.VisualBasic;

namespace APP1
{
    /// <summary>
    /// Логика взаимодействия для Waiter.xaml
    /// </summary>
    public partial class Waiter : Window
    {
        string connectionString;
        SqlConnection connection;
        public int result { get; set; }
        string number;
        string client;
        string name;
        string statusW;
        int selectedOrderId;
        DateTime? date;
        string fDate;
        DataTable datatable;
        SqlDataAdapter SqlUpdate;
        SqlCommandBuilder sqlSave;
        string sqlUpdate = @"SELECT Id, Date, Name, Number, Client, StatusW FROM Zakaz";

        public Waiter()
        {
          
            InitializeComponent();
            connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Учеба\\Готовый проект 2\\APP1\\FastFoodDB.mdf\";Integrated Security=True";
            connection = new SqlConnection(connectionString);
            connection.Open();
            FillMenuComboBox();
            FillGroupComboBox();
            dpZakazNew.SelectedDate = DateTime.Now;
            dgZakazView.DataContext = ExecuteSql("Select * from Zakaz");
            cbStatusW.ItemsSource = new List<string>() {"не оплачен","оплачен"};                      
            SqlUpdate = new SqlDataAdapter(sqlUpdate, connection);
            datatable = new DataTable();
            SqlUpdate.Fill(datatable);
            save();

        }

        DataTable ExecuteSql(string sql)
        {
            DataTable table = new();
            SqlCommand cmd = new(sql, connection);
            SqlDataReader read = cmd.ExecuteReader();
            using (read)
            {
                table.Load(read);
            }
            return table;
        }

        private void btnViewOrder_Click(object sender, RoutedEventArgs e)
        {
            Button btn = sender as Button;
            if (btn != null && btn.Tag != null)
            {
                selectedOrderId = (int)btn.Tag;

                TabItem viewOrderTab = MainTabControl.FindName("ZakazView") as TabItem;

                if (viewOrderTab != null)
                {
                    MainTabControl.SelectedItem = viewOrderTab;
                    dgOrder.DataContext = ExecuteSql($"SELECT Menu.Title AS ProductTitle, Menu.Price AS ProductPrice, ZakazMenu.Kolvo AS Quantity, Menu.Price * ZakazMenu.Kolvo AS TotalPrice FROM ZakazMenu JOIN Menu ON ZakazMenu.IdMenu = Menu.Id WHERE ZakazMenu.IdZakaz = '{selectedOrderId}'");
                }
                else
                {
                    viewOrderTab = new TabItem();
                    viewOrderTab.Header = "Просмотр заказов";
                    viewOrderTab.Name = "ZakazView";

                    MainTabControl.Items.Add(viewOrderTab);

                    MainTabControl.SelectedItem = viewOrderTab;
                    dgOrder.DataContext = ExecuteSql($"SELECT Menu.Title AS ProductTitle, Menu.Price AS ProductPrice, ZakazMenu.Kolvo AS Quantity, Menu.Price * ZakazMenu.Kolvo AS TotalPrice FROM ZakazMenu JOIN Menu ON ZakazMenu.IdMenu = Menu.Id WHERE ZakazMenu.IdZakaz = '{selectedOrderId}'");
                }
            }
        }

        private void btnZakazNew_Click(object sender, RoutedEventArgs e)
        {
            string sqlZakazInsert = "INSERT INTO Zakaz (Number,Client,Date,Name,StatusW) VALUES (@Number,@Client,@Date,@Name,@StatusW)";
            number = txtNumber.Text;
            client = txtClient.Text;
            name = txtName.Text;
            statusW = cbStatusW.Text;
            date = dpZakazNew.SelectedDate;
            using (SqlCommand command = new SqlCommand(sqlZakazInsert, connection))
            {
                command.Parameters.AddWithValue("@Number", number);
                command.Parameters.AddWithValue("@Client", client);
                command.Parameters.AddWithValue("@Date", date);
                command.Parameters.AddWithValue("@Name", name);
                command.Parameters.AddWithValue("@StatusW", statusW);
                int count = command.ExecuteNonQuery();
                if (count > 0) { lblMessageW.Content = "Заказ принят"; }
                else { lblMessageW.Content = "Заказ не принят"; }
            }   
        }

        private void btnZakazShowAll_Click(object sender, RoutedEventArgs e)
        {
            {
                dgZakazView.DataContext = ExecuteSql("Select * from Zakaz");
                sqlUpdate = @"SELECT Id, Date, Name, Number, Client, StatusW FROM Zakaz";
                save();
            }
        }
        private void FillMenuComboBox()
        {
            string sqlMenu = "SELECT Title FROM Menu";
            DataTable menuData = ExecuteSql(sqlMenu);
            cbMenu.ItemsSource = menuData.DefaultView;
        }
        
        private void FillGroupComboBox()
        {
                string sqlCat = "SELECT CatName FROM Category";
                DataTable menuCat = ExecuteSql(sqlCat);
                cbCat.ItemsSource = menuCat.DefaultView;
        }

        private void btnZakazDate_Click(object sender, RoutedEventArgs e)
        {
            date = dpZakazNew.SelectedDate;
            if (date.HasValue) 
            { 
                fDate = date.Value.ToString("yyyy - MM - dd HH : mm");
            }
            dgZakazView.DataContext = ExecuteSql($"Select * from Zakaz WHERE Date='{fDate}'");
        }

        private void btnZakazSave_Click(object sender, RoutedEventArgs e)
        {
            save();
        }
       
        private void save()
        {
            sqlSave = new SqlCommandBuilder(SqlUpdate);
            SqlUpdate.Update(datatable);
            SqlUpdate = new SqlDataAdapter(sqlUpdate, connection);
            datatable = new DataTable();
            SqlUpdate.Fill(datatable);
            dgZakazView.DataContext = datatable;
        }

        private void cbCat_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            string selectedCategory = (cbCat.SelectedItem as DataRowView)?.Row["CatName"].ToString();


            if (!string.IsNullOrEmpty(selectedCategory))
            {
                string sqlMenu = $"SELECT Title FROM Menu WHERE idCat = (SELECT Id FROM Category Where CatName=N'{selectedCategory}')";
                DataTable menuData = ExecuteSql(sqlMenu);
                cbMenu.ItemsSource = menuData.DefaultView;

            }
        }
        private void btnSbros_Click(object sender, RoutedEventArgs e)      
        {
                FillMenuComboBox();
                FillGroupComboBox();
        }

        private void btnMenuAdd_Click(object sender, RoutedEventArgs e)
        {
            string menu = cbMenu.Text;
            string kolvo = txtKolvoPorciy.Text;

            if (selectedOrderId != 0)
            {
                string sqlGetMenuId = $"SELECT Id FROM Menu WHERE Title = N'{menu}'";
                DataTable menuData = ExecuteSql(sqlGetMenuId);
                if (menuData.Rows.Count > 0)
                {
                    int menuId = Convert.ToInt32(menuData.Rows[0]["Id"]);
                    string sqlAddIntoZakazMenu = $"INSERT INTO ZakazMenu (IdZakaz, IdMenu, Kolvo) VALUES (@OrderId, @MenuId, @Quantity)";
                    using (SqlCommand command = new SqlCommand(sqlAddIntoZakazMenu, connection))
                    {
                        command.Parameters.AddWithValue("@OrderId", selectedOrderId);
                        command.Parameters.AddWithValue("@MenuId", menuId);
                        command.Parameters.AddWithValue("@Quantity", kolvo);

                        int count = command.ExecuteNonQuery();
                        if (count > 0)
                        {
                            MessageBox.Show("Товар успешно добавлен в заказ.");
                            dgOrder.DataContext = ExecuteSql($"SELECT Menu.Title AS ProductTitle, Menu.Price AS ProductPrice, ZakazMenu.Kolvo AS Quantity, Menu.Price * ZakazMenu.Kolvo AS TotalPrice FROM ZakazMenu JOIN Menu ON ZakazMenu.IdMenu = Menu.Id WHERE ZakazMenu.IdZakaz = '{selectedOrderId}'");                      
                        }
                        else
                        {
                            MessageBox.Show("Не удалось добавить товар в заказ.");
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Выбранный товар не найден.");
                }
            }
            else
            {
                MessageBox.Show("Сначала выберите заказ.");
            }

        }
        private void btnItog_Click(object sender, RoutedEventArgs e)
        {
                DataTable table = (DataTable)dgOrder.DataContext;

                if (table != null && table.Rows.Count > 0)
                {
                    int total = table.AsEnumerable().Sum(row => row.Field<int>("TotalPrice"));

                    MessageBox.Show($"Итоговая сумма: {total}");
                }
                else
                {
                    MessageBox.Show("Нет данных для подсчета.");
                }         
        }

        private void btnCloseWaiter_Click(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            connection.Close();
            Hide();
        }
    }
}
