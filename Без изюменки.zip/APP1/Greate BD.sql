﻿CREATE TABLE [dbo].[Roles] (
    [Id]   INT           IDENTITY (1, 1) NOT NULL,
    [Role] NVARCHAR (20) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

CREATE TABLE [dbo].[Users] (
    [Id]        INT           IDENTITY (1, 1) NOT NULL,
    [userName]  NVARCHAR (20) DEFAULT ('user') NOT NULL,
    [idRole]    INT           DEFAULT ((2)) NOT NULL,
    [userLogin] NVARCHAR (10) NOT NULL,
    [userPass]  NVARCHAR (20) NOT NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);

INSERT  INTO Roles (Role) VALUES (N'Директор');
INSERT  INTO Users (userName, idRole, userLogin, userPass) VALUES (N'Иван', 2, 'ivan', '9999');
INSERT  INTO Users (userName, idRole, userLogin, userPass) VALUES (N'Ольга', 3, 'olga', '2222');