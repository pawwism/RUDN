﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Data.SqlClient;

namespace APP1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        string connectionString;
        SqlConnection connection;
        string activeRole;
      

        public MainWindow()
        {
            InitializeComponent();
            connectionString = "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename=\"C:\\Учеба\\Готовый проект 2\\APP1\\FastFoodDB.mdf\";Integrated Security=True";
            connection = new SqlConnection(connectionString);
            connection.Open();
        }
        private void btnAvt_Click(object sender, RoutedEventArgs e)
        {
            string selectUsers = "SELECT * FROM Users WHERE userLogin=@Login and userPass=@Password";
            string login = txtLogin.Text;
            string password = passUser.Password;
            using (SqlCommand check = new SqlCommand(selectUsers, connection))
            {
                check.Parameters.AddWithValue("@Login", login);
                check.Parameters.AddWithValue("@Password", password);
                using (SqlDataReader reader = check.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        activeRole = reader["idRole"].ToString();                   
                        lblMessage.Content = $"Добро пожаловать, {reader["userName"]}";
                        btnNext.IsEnabled = true;
                    }
                    else
                    {
                        activeRole = "";
                        lblMessage.Content = $"Вы не прошли авторизацию";
                    }
                }
            }
        }
        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            if (activeRole == "2")
            {
                Admin admin = new Admin();
                admin.Show();
            }
            if (activeRole == "3")
            {
                Waiter waiter = new Waiter();
                waiter.Show();
            }

            connection.Close();
            Hide();

            if (activeRole == "4")
            {
                Cook cook = new Cook();
                cook.Show();
            }

            connection.Close();
            Hide();
        }
    }
}