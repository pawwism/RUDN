﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace Hotel
{
    public partial class Roomservice : Window
    {
        private readonly string _connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\user\Desktop\Hotel\hotel.mdf"";Integrated Security=True;Connect Timeout=30";
        private SqlConnection _connection;
        private int _currentUserId;
        private int _selectedOrderId;

        public Roomservice(int userId)
        {
            InitializeComponent();
            _currentUserId = userId;
            InitializeDatabaseConnection();
            LoadInitialData();
        }

        private void InitializeDatabaseConnection()
        {
            try
            {
                _connection = new SqlConnection(_connectionString);
                _connection.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}");
                Close();
            }
        }

        private void LoadInitialData()
        {
            LoadStatuses();
            LoadOrders();
            LoadMenuCategories();
            LoadAllMenuItems();
        }

        private void LoadStatuses()
        {
            cbStatusW.ItemsSource = new[] { "Не оплачен", "Оплачен", "В обработке", "Отменен" };
            cbStatusW.SelectedIndex = 0;
        }

        private void LoadOrders(DateTime? date = null)
        {
            try
            {
                using (var command = new SqlCommand("sp_GetRoomServiceOrders", _connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Убрали передачу параметра @Date, чтобы получить все заказы
                    // command.Parameters.AddWithValue("@Date", date.Value.Date); // Закомментировали эту строку

                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgZakazView.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки заказов: {ex.Message}");
            }
        }

        private void LoadMenuCategories()
        {
            try
            {
                using (var command = new SqlCommand("SELECT CategoryName FROM MenuCategories", _connection))
                {
                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    cbCat.ItemsSource = dataTable.DefaultView;
                    cbCat.DisplayMemberPath = "CategoryName";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки категорий: {ex.Message}");
            }
        }

        private void LoadAllMenuItems()
        {
            try
            {
                using (var command = new SqlCommand("SELECT ItemName FROM MenuItems WHERE IsAvailable = 1", _connection))
                {
                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    cbMenu.ItemsSource = dataTable.DefaultView;
                    cbMenu.DisplayMemberPath = "ItemName";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки меню: {ex.Message}");
            }
        }

        private void LoadMenuItemsByCategory(string categoryName)
        {
            try
            {
                using (var command = new SqlCommand(
                    @"SELECT ItemName FROM MenuItems mi 
                      JOIN MenuCategories mc ON mi.CategoryID = mc.CategoryID 
                      WHERE mc.CategoryName = @CategoryName AND mi.IsAvailable = 1",
                    _connection))
                {
                    command.Parameters.AddWithValue("@CategoryName", categoryName);

                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    cbMenu.ItemsSource = dataTable.DefaultView;
                    cbMenu.DisplayMemberPath = "ItemName";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки меню по категории: {ex.Message}");
            }
        }

        private void btnZakazDate_Click(object sender, RoutedEventArgs e)
        {
            var selectedDate = dpZakazNew.SelectedDate;
            LoadOrders(selectedDate);
        }

        private void btnZakazNew_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtName.Text) || string.IsNullOrEmpty(txtNumber.Text))
            {
                MessageBox.Show("Заполните имя клиента и номер комнаты!");
                return;
            }

            try
            {
                int roomId = GetRoomIdByNumber(txtNumber.Text);
                if (roomId == -1)
                {
                    MessageBox.Show("Номер комнаты не найден!");
                    return;
                }

                using (var command = new SqlCommand("sp_CreateRoomServiceOrder", _connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@RoomID", roomId);
                    command.Parameters.AddWithValue("@ClientName", txtName.Text);
                    command.Parameters.AddWithValue("@CreatedBy", _currentUserId);

                    int newOrderId = Convert.ToInt32(command.ExecuteScalar());

                    if (newOrderId > 0)
                    {
                        MessageBox.Show("Заказ успешно создан!");
                        LoadOrders();
                        ClearOrderFields();
                    }
                    else
                    {
                        MessageBox.Show("Ошибка при создании заказа!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private int GetRoomIdByNumber(string roomNumber)
        {
            try
            {
                using (var command = new SqlCommand("SELECT RoomID FROM Rooms WHERE RoomNumber = @RoomNumber", _connection))
                {
                    command.Parameters.AddWithValue("@RoomNumber", roomNumber);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1;
                }
            }
            catch
            {
                return -1;
            }
        }

        private void btnZakazSave_Click(object sender, RoutedEventArgs e)
        {
            if (dgZakazView.SelectedItem == null)
            {
                MessageBox.Show("Выберите заказ для сохранения!");
                return;
            }

            try
            {
                var rowView = (DataRowView)dgZakazView.SelectedItem;
                int orderId = Convert.ToInt32(rowView["Id"]);
                string status = rowView["StatusW"].ToString();

                using (var command = new SqlCommand(
                    "UPDATE RoomServiceOrders SET Status = @Status WHERE OrderID = @OrderID",
                    _connection))
                {
                    command.Parameters.AddWithValue("@OrderID", orderId);
                    command.Parameters.AddWithValue("@Status", status);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Статус заказа успешно обновлен!");
                        LoadOrders();
                    }
                    else
                    {
                        MessageBox.Show("Не удалось обновить статус заказа!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void btnZakazShowAll_Click(object sender, RoutedEventArgs e)
        {
            LoadOrders();
        }

        private void btnViewOrder_Click(object sender, RoutedEventArgs e)
        {
            if (dgZakazView.SelectedItem == null)
            {
                MessageBox.Show("Выберите заказ!");
                return;
            }

            var rowView = (DataRowView)dgZakazView.SelectedItem;
            _selectedOrderId = Convert.ToInt32(rowView["Id"]);

            LoadOrderDetails(_selectedOrderId);
        }

        private void LoadOrderDetails(int orderId)
        {
            try
            {
                using (var command = new SqlCommand("sp_GetOrderDetails", _connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@OrderID", orderId);

                    var adapter = new SqlDataAdapter(command);
                    var dataSet = new DataSet();
                    adapter.Fill(dataSet);

                    if (dataSet.Tables.Count > 1)
                    {
                        dgOrder.ItemsSource = dataSet.Tables[1].DefaultView;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки деталей заказа: {ex.Message}");
            }
        }

        private void btnMenuAdd_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedOrderId == 0)
            {
                MessageBox.Show("Сначала выберите заказ!");
                return;
            }

            if (string.IsNullOrEmpty(txtKolvoPorciy.Text) || !int.TryParse(txtKolvoPorciy.Text, out int quantity) || quantity <= 0)
            {
                MessageBox.Show("Введите корректное количество порций!");
                return;
            }

            if (cbMenu.SelectedItem == null)
            {
                MessageBox.Show("Выберите блюдо из меню!");
                return;
            }

            try
            {
                string itemName = ((DataRowView)cbMenu.SelectedItem)["ItemName"].ToString();
                decimal price = GetMenuItemPrice(itemName);

                if (price == -1)
                {
                    MessageBox.Show("Не удалось определить цену блюда!");
                    return;
                }

                using (var command = new SqlCommand("sp_AddOrderItem", _connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@OrderID", _selectedOrderId);
                    command.Parameters.AddWithValue("@ItemID", GetMenuItemId(itemName));
                    command.Parameters.AddWithValue("@Quantity", quantity);
                    command.Parameters.AddWithValue("@UnitPrice", price);

                    int newItemId = Convert.ToInt32(command.ExecuteScalar());

                    if (newItemId > 0)
                    {
                        MessageBox.Show("Блюдо успешно добавлено в заказ!");
                        LoadOrderDetails(_selectedOrderId);
                        txtKolvoPorciy.Clear();
                    }
                    else
                    {
                        MessageBox.Show("Ошибка при добавлении блюда в заказ!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private int GetMenuItemId(string itemName)
        {
            try
            {
                using (var command = new SqlCommand(
                    "SELECT ItemID FROM MenuItems WHERE ItemName = @ItemName",
                    _connection))
                {
                    command.Parameters.AddWithValue("@ItemName", itemName);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1;
                }
            }
            catch
            {
                return -1;
            }
        }

        private decimal GetMenuItemPrice(string itemName)
        {
            try
            {
                using (var command = new SqlCommand(
                    "SELECT Price FROM MenuItems WHERE ItemName = @ItemName",
                    _connection))
                {
                    command.Parameters.AddWithValue("@ItemName", itemName);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToDecimal(result) : -1;
                }
            }
            catch
            {
                return -1;
            }
        }

        private void btnItog_Click(object sender, RoutedEventArgs e)
        {
            if (_selectedOrderId == 0)
            {
                MessageBox.Show("Сначала выберите заказ!");
                return;
            }

            try
            {
                using (var command = new SqlCommand(
                    "SELECT TotalAmount FROM RoomServiceOrders WHERE OrderID = @OrderID",
                    _connection))
                {
                    command.Parameters.AddWithValue("@OrderID", _selectedOrderId);
                    var result = command.ExecuteScalar();
                    if (result != null)
                    {
                        decimal total = Convert.ToDecimal(result);
                        MessageBox.Show($"Итоговая сумма заказа: {total} руб.");
                    }
                    else
                    {
                        MessageBox.Show("Не удалось получить сумму заказа!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void btnSbros_Click(object sender, RoutedEventArgs e)
        {
            LoadAllMenuItems();
            cbCat.SelectedIndex = -1;
            txtKolvoPorciy.Clear();
        }

        private void cbCat_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbCat.SelectedItem != null)
            {
                string categoryName = ((DataRowView)cbCat.SelectedItem)["CategoryName"].ToString();
                LoadMenuItemsByCategory(categoryName);
            }
        }

        private void ClearOrderFields()
        {
            txtName.Clear();
            txtNumber.Clear();
            txtClient.Clear();
            cbStatusW.SelectedIndex = 0;
        }

        private void Button_Click_Main(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            _connection?.Close();
        }
    }
}
