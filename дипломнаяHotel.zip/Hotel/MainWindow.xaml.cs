﻿using System;
using System.Windows;
using System.Data.SqlClient;
using System.Windows.Media;
using System.Windows.Controls;
using System.Windows.Data;
using System.Diagnostics;



namespace Hotel
{
    public partial class MainWindow : Window
    {
        private SqlConnection _connection;
        private string _activeRoleID;
        private int _userId;
       

        public MainWindow()
        {
            InitializeComponent();
            InitializeDatabaseConnection();
        }

        private void InitializeDatabaseConnection()
        {
            try
            {
                // Используем прямое подключение без ConfigurationManager
                string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\user\Desktop\Hotel\hotel.mdf"";Integrated Security=True;Connect Timeout=30";
                _connection = new SqlConnection(connectionString);
                _connection.Open();

                // Если у вас нет lblConnectionStatus, можно использовать lblMessage или другой элемент
                lblMessage.Content = "Подключено к БД";
                lblMessage.Foreground = Brushes.Green;
            }
            catch (Exception ex)
            {
                lblMessage.Content = "Ошибка подключения: " + ex.Message;
                lblMessage.Foreground = Brushes.Red;
                btnAvt.IsEnabled = false;
            }
        }

        private void btnAvt_Click(object sender, RoutedEventArgs e)
        {
            string login = txtLogin.Text.Trim();
            string password = passUser.Password;
            Debug.WriteLine($"Роль пользователя: {_activeRoleID}");

            if (string.IsNullOrEmpty(login) || string.IsNullOrEmpty(password))
            {
                lblMessage.Content = "Введите логин и пароль";
                return;
            }

            try
            {
                using (var command = new SqlCommand("sp_AuthenticateUser", _connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@Login", login);
                    command.Parameters.AddWithValue("@Password", password);

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            _userId = Convert.ToInt32(reader["UserID"]);
                            _activeRoleID = reader["RoleID"].ToString();
                            lblMessage.Content = $"Добро пожаловать, {reader["FullName"]}";
                            btnNext.IsEnabled = true;
                        }
                        else
                        {
                            lblMessage.Content = "Неверный логин или пароль";
                            btnNext.IsEnabled = false;
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                lblMessage.Content = "Ошибка авторизации: " + ex.Message;
            }
        }

        private void btnNext_Click(object sender, RoutedEventArgs e)
        {
            Debug.WriteLine("Метод btnNext_Click вызван"); // Вывод в Output window

            if (string.IsNullOrEmpty(_activeRoleID))
            {
                MessageBox.Show("Сначала выполните вход");
                return;
            }

            if (_activeRoleID == "1")
            {  
                Администратор администратор = new Администратор(_userId);
                администратор.Show();
            }
            if (_activeRoleID == "2")
            {
                Manager manager = new Manager(_userId);
                manager.Show();
            }
            if (_activeRoleID == "5")
            {
                Roomservice roomservice = new Roomservice(_userId);
                roomservice.Show();
            }        
        }
    }
}
