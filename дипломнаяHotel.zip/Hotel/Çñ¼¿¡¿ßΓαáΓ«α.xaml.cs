﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace Hotel
{

    public partial class Администратор : Window
    {
        private SqlConnection _connection;
        private string _activeRoleID;
        private int _userId;


        public Администратор(int userId)
        {
            InitializeComponent();
            InitializeDatabaseConnection();
            _currentUserId = userId;
            LoadInitialData();
        }

        private void InitializeDatabaseConnection()
        {
            try
            {
                // Используем прямое подключение без ConfigurationManager
                string connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\user\Desktop\Hotel\hotel.mdf"";Integrated Security=True;Connect Timeout=30";
                _connection = new SqlConnection(connectionString);
                _connection.Open();
            }

            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка инициализации: {ex.Message}");
                this.Close();
            }


        }

        private readonly int _currentUserId;

        private void LoadInitialData()
        {
            LoadRoles();
            LoadStatuses();
            LoadEmployees();
            LoadShifts();
            LoadBookings();
            LoadEmployeesForComboBoxes();
        }

        #region Общие методы

        private void LoadRoles()
        {
            try
            {
                DataTable dt = new DataTable();
                string query = "SELECT RoleName FROM Roles";

                using (SqlCommand cmd = new SqlCommand(query, _connection))
                {
                    _connection.Open();
                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }

                cbRole.ItemsSource = dt.DefaultView;
                cbRole.DisplayMemberPath = "RoleName";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки ролей: {ex.Message}");
            }
            finally
            {
                if (_connection.State != ConnectionState.Closed)
                    _connection.Close();
            }
        }

        private void LoadStatuses()
        {
            cbStatus.Items.Add("Активен");
            cbStatus.Items.Add("Заблокирован");
            cbStatus.Items.Add("В отпуске");
            cbStatus.SelectedIndex = 0;
        }

        #endregion

        #region Вкладка "Сотрудники"

        private void LoadEmployees()
        {
            try
            {
                DataTable dt = new DataTable();

                using (SqlCommand cmd = new SqlCommand("sp_GetEmployees", _connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    _connection.Open();

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }

                listUser.ItemsSource = dt.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки сотрудников: {ex.Message}");
            }
            finally
            {
                if (_connection.State != ConnectionState.Closed)
                    _connection.Close();
            }
        }

        private void btnReg_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtLogin.Text) || string.IsNullOrEmpty(txtPassword.Text) ||
                string.IsNullOrEmpty(txtName.Text) || cbRole.SelectedItem == null)
            {
                MessageBox.Show("Заполните все обязательные поля!");
                return;
            }

            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_AddEmployee", _connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Login", txtLogin.Text);
                    cmd.Parameters.AddWithValue("@Password", txtPassword.Text);
                    cmd.Parameters.AddWithValue("@FullName", txtName.Text);
                    cmd.Parameters.AddWithValue("@RoleName", ((DataRowView)cbRole.SelectedItem)["RoleName"]);
                    cmd.Parameters.AddWithValue("@Status", cbStatus.SelectedItem.ToString());
                    cmd.Parameters.AddWithValue("@CreatedBy", _currentUserId);

                    _connection.Open();
                    int newUserId = Convert.ToInt32(cmd.ExecuteScalar());

                    if (newUserId > 0)
                    {
                        MessageBox.Show("Сотрудник успешно добавлен!");
                        LoadEmployees();
                        ClearEmployeeFields();
                    }
                    else
                    {
                        MessageBox.Show("Ошибка при добавлении сотрудника!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
            finally
            {
                if (_connection.State != ConnectionState.Closed)
                    _connection.Close();
            }
        }

        private void btnSave_Click(object sender, RoutedEventArgs e)
        {
            // Реализация сохранения изменений сотрудника
            // Аналогично btnReg_Click, но с UPDATE запросом
        }

        private void btnUserView_Click(object sender, RoutedEventArgs e)
        {
            LoadEmployees();
        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {
            // Реализация поиска сотрудников
        }

        private void ClearEmployeeFields()
        {
            txtLogin.Clear();
            txtPassword.Clear();
            txtName.Clear();
            cbRole.SelectedIndex = -1;
            cbStatus.SelectedIndex = 0;
        }

        #endregion

        #region Вкладка "Смены"

        private void LoadShifts()
        {
            try
            {
                DataTable dt = new DataTable();

                using (SqlCommand cmd = new SqlCommand("sp_GetShifts", _connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    _connection.Open();

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }

                listSmena.ItemsSource = dt.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки смен: {ex.Message}");
            }
            finally
            {
                if (_connection.State != ConnectionState.Closed)
                    _connection.Close();
            }
        }

        private void LoadEmployeesForComboBoxes()
        {
            LoadEmployeesForComboBox(cbAdmin, "Администратор");
            LoadEmployeesForComboBox(cbHousemaid, "Менеджер");
            LoadEmployeesForComboBox(cbRoomservice, "Официант");
        }

        private void LoadEmployeesForComboBox(ComboBox comboBox, string roleFilter)
        {
            try
            {
                DataTable dt = new DataTable();
                string query = @"SELECT u.UserID, u.FullName 
                               FROM Users u
                               JOIN Roles r ON u.RoleID = r.RoleID
                               WHERE r.RoleName = @RoleName";

                using (SqlCommand cmd = new SqlCommand(query, _connection))
                {
                    cmd.Parameters.AddWithValue("@RoleName", roleFilter);
                    _connection.Open();

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }

                comboBox.ItemsSource = dt.DefaultView;
                comboBox.DisplayMemberPath = "FullName";
                comboBox.SelectedValuePath = "UserID";
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки сотрудников для {roleFilter}: {ex.Message}");
            }
            finally
            {
                if (_connection.State != ConnectionState.Closed)
                    _connection.Close();
            }
        }

        private void btnSmenaView_Click(object sender, RoutedEventArgs e)
        {
            LoadShifts();
        }

        private void btnSmenaDate_Click(object sender, RoutedEventArgs e)
        {
            if (dpSmena.SelectedDate == null)
            {
                MessageBox.Show("Выберите дату!");
                return;
            }

            try
            {
                DataTable dt = new DataTable();

                using (SqlCommand cmd = new SqlCommand("sp_GetShifts", _connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@Date", dpSmena.SelectedDate);
                    _connection.Open();

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }

                listSmena.ItemsSource = dt.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки смен: {ex.Message}");
            }
            finally
            {
                if (_connection.State != ConnectionState.Closed)
                    _connection.Close();
            }
        }

        private void btnSaveSmena_Click(object sender, RoutedEventArgs e)
        {
            if (dpSmena.SelectedDate == null || cbAdmin.SelectedValue == null ||
                cbHousemaid.SelectedValue == null || cbRoomservice.SelectedValue == null)
            {
                MessageBox.Show("Заполните все поля!");
                return;
            }

            try
            {
                using (SqlCommand cmd = new SqlCommand("sp_CreateShift", _connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    cmd.Parameters.AddWithValue("@ShiftDate", dpSmena.SelectedDate);
                    cmd.Parameters.AddWithValue("@AdminID", cbAdmin.SelectedValue);
                    cmd.Parameters.AddWithValue("@ManagerID", cbHousemaid.SelectedValue);
                    cmd.Parameters.AddWithValue("@RoomServiceID", cbRoomservice.SelectedValue);
                    cmd.Parameters.AddWithValue("@CreatedBy", _currentUserId);

                    _connection.Open();
                    int newShiftId = Convert.ToInt32(cmd.ExecuteScalar());

                    if (newShiftId > 0)
                    {
                        MessageBox.Show("Смена успешно создана!");
                        LoadShifts();
                    }
                    else
                    {
                        MessageBox.Show("Смена на эту дату уже существует!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
            finally
            {
                if (_connection.State != ConnectionState.Closed)
                    _connection.Close();
            }
        }

        #endregion

        #region Вкладка "Бронирования"

        private void LoadBookings()
        {
            try
            {
                DataTable dt = new DataTable();

                using (SqlCommand cmd = new SqlCommand("sp_GetBookings", _connection))
                {
                    cmd.CommandType = CommandType.StoredProcedure;
                    _connection.Open();

                    using (SqlDataAdapter da = new SqlDataAdapter(cmd))
                    {
                        da.Fill(dt);
                    }
                }

                dgZakazView.ItemsSource = dt.DefaultView;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки бронирований: {ex.Message}");
            }
            finally
            {
                if (_connection.State != ConnectionState.Closed)
                    _connection.Close();
            }
        }

        private void btnViewOrder_Click(object sender, RoutedEventArgs e)
        {
            if (dgZakazView.SelectedItem == null) return;

            DataRowView row = (DataRowView)dgZakazView.SelectedItem;
            int orderId = Convert.ToInt32(row["Id"]);


        }

        #endregion

        private void Button_Click_Main(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }
    }
}