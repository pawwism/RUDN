﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows;
using System.Windows.Controls;

namespace Hotel
{
    public partial class Manager : Window
    {
        private readonly string _connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\user\Desktop\Hotel\hotel.mdf"";Integrated Security=True;Connect Timeout=30";
        private SqlConnection _connection;
        private int _currentUserId;

        public Manager(int userId)
        {
            InitializeComponent();
            _currentUserId = userId;
            InitializeDatabaseConnection();
            LoadInitialData();
        }

        private void InitializeDatabaseConnection()
        {
            try
            {
                _connection = new SqlConnection(_connectionString);
                _connection.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка подключения к базе данных: {ex.Message}");
                Close();
            }
        }

        private void LoadInitialData()
        {
            LoadRoomTypes();
            LoadBookings();
            LoadRooms();
            LoadEmployees();
        }

        private void LoadRoomTypes()
        {
            try
            {
                using (var command = new SqlCommand("SELECT TypeName FROM RoomTypes", _connection))
                {
                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    cbRoomType.ItemsSource = dataTable.DefaultView;
                    cbRoomType.DisplayMemberPath = "TypeName";

                    cbRoomTypeManagement.ItemsSource = dataTable.DefaultView;
                    cbRoomTypeManagement.DisplayMemberPath = "TypeName";
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки типов номеров: {ex.Message}");
            }
        }

        private void LoadBookings(DateTime? startDate = null, DateTime? endDate = null)
        {
            try
            {
                using (var command = new SqlCommand("sp_GetBookings", _connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    if (startDate.HasValue)
                        command.Parameters.AddWithValue("@StartDate", startDate.Value.Date);

                    if (endDate.HasValue)
                        command.Parameters.AddWithValue("@EndDate", endDate.Value.Date);

                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgBookings.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки бронирований: {ex.Message}");
            }
        }

        private void LoadRooms()
        {
            try
            {
                using (var command = new SqlCommand(
                    @"SELECT r.RoomNumber, rt.TypeName AS RoomType, r.Status, 
                             rt.BasePrice AS Price, NULL AS AvailableDate
                      FROM Rooms r
                      JOIN RoomTypes rt ON r.RoomTypeID = rt.RoomTypeID", _connection))
                {
                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgRooms.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки номеров: {ex.Message}");
            }
        }

        private void LoadEmployees()
        {
            try
            {
                using (var command = new SqlCommand("sp_GetEmployees", _connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgEmployees.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка загрузки сотрудников: {ex.Message}");
            }
        }

        private void btnCreateBooking_Click(object sender, RoutedEventArgs e)
        {
            if (string.IsNullOrEmpty(txtClientName.Text) ||
                dpCheckIn.SelectedDate == null ||
                dpCheckOut.SelectedDate == null ||
                cbRoomType.SelectedItem == null ||
                string.IsNullOrEmpty(txtGuestsCount.Text) ||
                cbBookingType.SelectedItem == null)
            {
                MessageBox.Show("Заполните все обязательные поля!");
                return;
            }

            try
            {
                string roomType = ((DataRowView)cbRoomType.SelectedItem)["TypeName"].ToString();
                int roomId = GetAvailableRoomId(roomType, dpCheckIn.SelectedDate.Value, dpCheckOut.SelectedDate.Value);

                if (roomId == -1)
                {
                    MessageBox.Show("Нет доступных номеров выбранного типа на указанные даты!");
                    return;
                }

                using (var command = new SqlCommand("sp_CreateBooking", _connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@ClientName", txtClientName.Text);
                    command.Parameters.AddWithValue("@ClientPhone", "");
                    command.Parameters.AddWithValue("@ClientEmail", "");
                    command.Parameters.AddWithValue("@RoomID", roomId);
                    command.Parameters.AddWithValue("@CheckInDate", dpCheckIn.SelectedDate);
                    command.Parameters.AddWithValue("@CheckOutDate", dpCheckOut.SelectedDate);
                    command.Parameters.AddWithValue("@Adults", int.Parse(txtGuestsCount.Text));
                    command.Parameters.AddWithValue("@Children", 0);
                    command.Parameters.AddWithValue("@BookingType", ((ComboBoxItem)cbBookingType.SelectedItem).Content.ToString());
                    command.Parameters.AddWithValue("@CreatedBy", _currentUserId);

                    int newBookingId = Convert.ToInt32(command.ExecuteScalar());

                    if (newBookingId > 0)
                    {
                        MessageBox.Show("Бронирование успешно создано!");
                        LoadBookings();
                        LoadRooms();
                        ClearBookingFields();
                    }
                    else
                    {
                        MessageBox.Show("Ошибка при создании бронирования!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private int GetAvailableRoomId(string roomType, DateTime checkInDate, DateTime checkOutDate)
        {
            try
            {
                using (var command = new SqlCommand("sp_GetAvailableRooms", _connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CheckInDate", checkInDate);
                    command.Parameters.AddWithValue("@CheckOutDate", checkOutDate);
                    command.Parameters.AddWithValue("@RoomTypeID", GetRoomTypeId(roomType));

                    using (var reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            return reader.GetInt32(0); // RoomID
                        }
                    }
                }
            }
            catch
            {
                return -1;
            }
            return -1;
        }

        private int GetRoomTypeId(string typeName)
        {
            try
            {
                using (var command = new SqlCommand(
                    "SELECT RoomTypeID FROM RoomTypes WHERE TypeName = @TypeName",
                    _connection))
                {
                    command.Parameters.AddWithValue("@TypeName", typeName);
                    var result = command.ExecuteScalar();
                    return result != null ? Convert.ToInt32(result) : -1;
                }
            }
            catch
            {
                return -1;
            }
        }

        private void btnCancelBooking_Click(object sender, RoutedEventArgs e)
        {
            if (dgBookings.SelectedItem == null)
            {
                MessageBox.Show("Выберите бронирование для отмены!");
                return;
            }

            try
            {
                var rowView = (DataRowView)dgBookings.SelectedItem;
                int bookingId = Convert.ToInt32(rowView["Id"]);

                using (var command = new SqlCommand(
                    "UPDATE Bookings SET Status = 'Отменено' WHERE BookingID = @BookingID",
                    _connection))
                {
                    command.Parameters.AddWithValue("@BookingID", bookingId);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Бронирование успешно отменено!");
                        LoadBookings();
                        LoadRooms();
                    }
                    else
                    {
                        MessageBox.Show("Не удалось отменить бронирование!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void btnConfirmBooking_Click(object sender, RoutedEventArgs e)
        {
            if (dgBookings.SelectedItem == null)
            {
                MessageBox.Show("Выберите бронирование для подтверждения!");
                return;
            }

            try
            {
                var rowView = (DataRowView)dgBookings.SelectedItem;
                int bookingId = Convert.ToInt32(rowView["Id"]);

                using (var command = new SqlCommand(
                    "UPDATE Bookings SET Status = 'Подтверждено' WHERE BookingID = @BookingID",
                    _connection))
                {
                    command.Parameters.AddWithValue("@BookingID", bookingId);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Бронирование успешно подтверждено!");
                        LoadBookings();
                    }
                    else
                    {
                        MessageBox.Show("Не удалось подтвердить бронирование!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void btnEditBooking_Click(object sender, RoutedEventArgs e)
        {
            if (dgBookings.SelectedItem == null)
            {
                MessageBox.Show("Выберите бронирование для редактирования!");
                return;
            }

            try
            {
                var rowView = (DataRowView)dgBookings.SelectedItem;

                txtClientName.Text = rowView["ClientName"].ToString();
                dpCheckIn.SelectedDate = Convert.ToDateTime(rowView["CheckInDate"]);
                dpCheckOut.SelectedDate = Convert.ToDateTime(rowView["CheckOutDate"]);
                txtGuestsCount.Text = rowView["Client"].ToString();

                string bookingType = rowView["BookingType"].ToString();
                foreach (ComboBoxItem item in cbBookingType.Items)
                {
                    if (item.Content.ToString() == bookingType)
                    {
                        cbBookingType.SelectedItem = item;
                        break;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void btnAssignRoom_Click(object sender, RoutedEventArgs e)
        {
            if (dpCheckIn.SelectedDate == null || dpCheckOut.SelectedDate == null || cbRoomTypeManagement.SelectedItem == null)
            {
                MessageBox.Show("Выберите даты и тип номера!");
                return;
            }

            try
            {
                string roomType = ((DataRowView)cbRoomTypeManagement.SelectedItem)["TypeName"].ToString();

                using (var command = new SqlCommand("sp_GetAvailableRooms", _connection))
                {
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.AddWithValue("@CheckInDate", dpCheckIn.SelectedDate);
                    command.Parameters.AddWithValue("@CheckOutDate", dpCheckOut.SelectedDate);
                    command.Parameters.AddWithValue("@RoomTypeID", GetRoomTypeId(roomType));

                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgRooms.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void btnChangeRoomStatus_Click(object sender, RoutedEventArgs e)
        {
            if (dgRooms.SelectedItem == null || cbRoomStatus.SelectedItem == null)
            {
                MessageBox.Show("Выберите номер и новый статус!");
                return;
            }

            try
            {
                var rowView = (DataRowView)dgRooms.SelectedItem;
                string roomNumber = rowView["RoomNumber"].ToString();
                string newStatus = ((ComboBoxItem)cbRoomStatus.SelectedItem).Content.ToString();

                using (var command = new SqlCommand(
                    "UPDATE Rooms SET Status = @Status WHERE RoomNumber = @RoomNumber",
                    _connection))
                {
                    command.Parameters.AddWithValue("@Status", newStatus);
                    command.Parameters.AddWithValue("@RoomNumber", roomNumber);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Статус номера успешно изменен!");
                        LoadRooms();
                    }
                    else
                    {
                        MessageBox.Show("Не удалось изменить статус номера!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void btnEditRoom_Click(object sender, RoutedEventArgs e)
        {
            if (dgRooms.SelectedItem == null)
            {
                MessageBox.Show("Выберите номер для редактирования!");
                return;
            }

            try
            {
                var rowView = (DataRowView)dgRooms.SelectedItem;

                string roomType = rowView["RoomType"].ToString();
                foreach (DataRowView item in cbRoomTypeManagement.Items)
                {
                    if (item["TypeName"].ToString() == roomType)
                    {
                        cbRoomTypeManagement.SelectedItem = item;
                        break;
                    }
                }

                string status = rowView["Status"].ToString();
                foreach (ComboBoxItem item in cbRoomStatus.Items)
                {
                    if (item.Content.ToString() == status)
                    {
                        cbRoomStatus.SelectedItem = item;
                        break;
                    }
                }

                dpRoomChangeDate.SelectedDate = DateTime.Now;
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void btnGenerateReport_Click(object sender, RoutedEventArgs e)
        {
            if (dpReportStart.SelectedDate == null || dpReportEnd.SelectedDate == null)
            {
                MessageBox.Show("Выберите период для отчета!");
                return;
            }

            try
            {
                // Отчет по бронированиям
                using (var command = new SqlCommand(
                    "SELECT * FROM Bookings WHERE CheckInDate BETWEEN @StartDate AND @EndDate",
                    _connection))
                {
                    command.Parameters.AddWithValue("@StartDate", dpReportStart.SelectedDate);
                    command.Parameters.AddWithValue("@EndDate", dpReportEnd.SelectedDate);

                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgBookingStats.ItemsSource = dataTable.DefaultView;
                }

                // Финансовый отчет
                using (var command = new SqlCommand(
                    "SELECT * FROM FinancialTransactions WHERE CreatedDate BETWEEN @StartDate AND @EndDate",
                    _connection))
                {
                    command.Parameters.AddWithValue("@StartDate", dpReportStart.SelectedDate);
                    command.Parameters.AddWithValue("@EndDate", dpReportEnd.SelectedDate);

                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgFinancialReport.ItemsSource = dataTable.DefaultView;
                }

                // Загрузка номеров
                using (var command = new SqlCommand(
                    @"SELECT r.RoomNumber, 
                             COUNT(b.BookingID) AS BookingCount,
                             SUM(b.TotalAmount) AS TotalRevenue
                      FROM Rooms r
                      LEFT JOIN Bookings b ON r.RoomID = b.RoomID 
                          AND b.CheckInDate BETWEEN @StartDate AND @EndDate
                      GROUP BY r.RoomNumber",
                    _connection))
                {
                    command.Parameters.AddWithValue("@StartDate", dpReportStart.SelectedDate);
                    command.Parameters.AddWithValue("@EndDate", dpReportEnd.SelectedDate);

                    var adapter = new SqlDataAdapter(command);
                    var dataTable = new DataTable();
                    adapter.Fill(dataTable);

                    dgRoomOccupancy.ItemsSource = dataTable.DefaultView;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка генерации отчетов: {ex.Message}");
            }
        }

        private void btnPromoteEmployee_Click(object sender, RoutedEventArgs e)
        {
            if (dgEmployees.SelectedItem == null)
            {
                MessageBox.Show("Выберите сотрудника для повышения!");
                return;
            }

            try
            {
                var rowView = (DataRowView)dgEmployees.SelectedItem;
                int userId = Convert.ToInt32(rowView["UserID"]);

                using (var command = new SqlCommand(
                    "UPDATE Users SET RoleID = RoleID + 1 WHERE UserID = @UserID AND RoleID < (SELECT MAX(RoleID) FROM Roles)",
                    _connection))
                {
                    command.Parameters.AddWithValue("@UserID", userId);

                    int rowsAffected = command.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("Сотрудник успешно повышен!");
                        LoadEmployees();
                    }
                    else
                    {
                        MessageBox.Show("Не удалось повысить сотрудника (возможно, уже имеет максимальную роль)!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void btnViewEmployeeStats_Click(object sender, RoutedEventArgs e)
        {
            if (dgEmployees.SelectedItem == null)
            {
                MessageBox.Show("Выберите сотрудника!");
                return;
            }

            try
            {
                var rowView = (DataRowView)dgEmployees.SelectedItem;
                int userId = Convert.ToInt32(rowView["UserID"]);

                using (var command = new SqlCommand(
                    "SELECT COUNT(*) FROM Bookings WHERE CreatedBy = @UserID",
                    _connection))
                {
                    command.Parameters.AddWithValue("@UserID", userId);
                    int bookingsCount = Convert.ToInt32(command.ExecuteScalar());

                    MessageBox.Show($"Сотрудник оформил {bookingsCount} бронирований");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        private void ClearBookingFields()
        {
            txtClientName.Clear();
            dpCheckIn.SelectedDate = null;
            dpCheckOut.SelectedDate = null;
            cbRoomType.SelectedIndex = -1;
            txtGuestsCount.Clear();
            cbBookingType.SelectedIndex = 0;
        }

        private void Button_Click_Main(object sender, RoutedEventArgs e)
        {
            MainWindow mainWindow = new MainWindow();
            mainWindow.Show();
            this.Close();
        }

        public class InputDialog : Window
        {
            public string ResponseText { get; set; }

            public InputDialog(string prompt)
            {
                Width = 300;
                Height = 150;
                WindowStartupLocation = WindowStartupLocation.CenterOwner;
                Title = prompt;

                var label = new Label { Content = prompt, Margin = new Thickness(10) };
                var textBox = new TextBox { Margin = new Thickness(10, 30, 10, 10) };
                var button = new Button { Content = "OK", IsDefault = true, Margin = new Thickness(10, 70, 10, 10) };

                button.Click += (sender, e) =>
                {
                    ResponseText = textBox.Text;
                    DialogResult = true;
                };

                var stackPanel = new StackPanel();
                stackPanel.Children.Add(label);
                stackPanel.Children.Add(textBox);
                stackPanel.Children.Add(button);

                Content = stackPanel;
            }
        }

        private void btnChangeSalary_Click(object sender, RoutedEventArgs e)
        {
            if (dgEmployees.SelectedItem == null)
            {
                MessageBox.Show("Выберите сотрудника для изменения зарплаты!");
                return;
            }

            try
            {
                var rowView = (DataRowView)dgEmployees.SelectedItem;
                int userId = Convert.ToInt32(rowView["UserID"]);

                // Запрос новой зарплаты через диалоговое окно
                var inputDialog = new InputDialog("Введите новую зарплату:");
                if (inputDialog.ShowDialog() == true)
                {
                    if (decimal.TryParse(inputDialog.ResponseText, out decimal newSalary))
                    {
                        using (var command = new SqlCommand(
                            "UPDATE Users SET Salary = @Salary WHERE UserID = @UserID",
                            _connection))
                        {
                            command.Parameters.AddWithValue("@Salary", newSalary);
                            command.Parameters.AddWithValue("@UserID", userId);

                            int rowsAffected = command.ExecuteNonQuery();

                            if (rowsAffected > 0)
                            {
                                MessageBox.Show("Зарплата успешно изменена!");
                                LoadEmployees();
                            }
                            else
                            {
                                MessageBox.Show("Не удалось изменить зарплату!");
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Введите корректную сумму зарплаты!");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }

        protected override void OnClosed(EventArgs e)
        {
            base.OnClosed(e);
            _connection?.Close();
        }
    }
}